from setuptools import setup, find_packages

setup(
    name='hello-cloud-functions',

    version='1.0.0-SNAPSHOT',

    description='',
    long_description='',

    author='Steve Willis',
    author_email='some@email.com',

    license='Copyright (c) 2018. All rights reserved.',

    packages=find_packages(),
    namespace_packages=['hello-cloud-functions'],
    zip_safe=False,
)

