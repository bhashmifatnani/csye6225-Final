from flask import request, json

def foos():
    result = {}
    result["codes"] = ["0"]
    result["messages"] = ["SUCCESS"]
    result["data"] = [ "foo1", "foo2" ] 
    return json.dumps(result) 
